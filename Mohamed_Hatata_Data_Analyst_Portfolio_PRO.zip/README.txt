Mohamed Hatata — Data Analyst Portfolio

Files:
- index.html
- style.css

Open index.html in a browser to view the site.

Important:
The dashboard figures are clearly labeled as illustrative sample visuals, not real business results. Replace them with actual project data/screenshots when you have them.
